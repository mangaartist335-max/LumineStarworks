IMPACT OF EDEN (2013) - OFFLINE UNIVERSE MODE
======================================================

This folder contains a full offline mockup of the Eden Episode 1 release
weekend as it might have appeared across the web in October 2013.

QUICK START
-----------
Double-click ONE of these to begin:

  1. google.html      -> The Google search results page (best entry point).
                         From here, click any blue link to visit the
                         corresponding fake site.

  2. index.html       -> Drop directly into the YourAnimeList Episode 1
                         Discussion thread. Page 1 of 56.

  3. Or pick any individual site:
       - aniwire_impact_of_eden_premiere.html  (AniWire premiere review)
       - munchyroll_impact_of_eden.html        (MunchyRoll streaming page)
       - sakugathread_impact_of_eden.html      (SakugaThread megathread)
       - anifanwiki_impact_of_eden.html        (AniFanWiki article)
       - threadit_impact_of_eden.html          (Threadit / Reddit clone)
       - adultdrift_impact_of_eden.html        (AdultDrift dub announcement)

EVERYTHING IS OFFLINE
---------------------
No internet connection, no server, no install required. Every page loads
locally and every link inside the folder is a relative path. Cross-site
links between the fake Eden-universe pages work as long as all files stay
in the same folder.

FILES IN THIS BUNDLE
--------------------
- 1 Google search page (google.html)
- 6 supporting fake-website pages (AniWire, MunchyRoll, SakugaThread,
  AniFanWiki, Threadit, AdultDrift)
- 56 YAL Episode 1 Discussion thread pages (index.html + page2..page56)
- 3 forum-shared assets (styles.css, avatars.svg, forum.js)

= about 65 files total, ~2 MB unzipped.

ABOUT
-----
Built for use with the Impact of Eden (2013) universe. All shown
parodies, networks, sites, and usernames are original parody designs for
the Eden universe. No real-world copyrighted properties are referenced.

Enjoy the offline universe mode.
